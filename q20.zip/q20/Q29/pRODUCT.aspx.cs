﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Q29
{
    public partial class pRODUCT : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            SqlDataAdapter da = new SqlDataAdapter("Select * from product", cnstr);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext obj = new DataClasses1DataContext(@"Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            product objprod = new product();
            objprod.ProductID = Convert.ToInt16(txtprodid.Text);
            objprod.ProductName = txtprodn.Text;
            objprod.UnitPrice = Convert.ToInt16(txtUP.Text);
            objprod.Quantity = Convert.ToInt16(txtQTY.Text);
            obj.products.InsertOnSubmit(objprod);
            obj.SubmitChanges();
            Response.Write("Inserted successfully");
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext objprod = new DataClasses1DataContext("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            product pro = objprod.products.Single(a => a.ProductID == Convert.ToInt16(txtprodid.Text));

            pro.ProductName = txtprodn.Text;
            pro.UnitPrice = Convert.ToInt16(txtUP.Text);

            pro.Quantity = Convert.ToInt16(txtQTY.Text);

            objprod.SubmitChanges();

            GridView1.DataBind();

            Response.Write("updated successfully");
        }

        protected void btndel_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext obj = new DataClasses1DataContext(@"Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            string sc = @" delete from product where ProductID =" + txtprodid.Text;
            DataSet ds = new DataSet();
            string s = txtprodid.Text.ToString();
            SqlDataAdapter da = new SqlDataAdapter(sc, cnstr);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            var dat = from c in obj.products where c.ProductID == Convert.ToInt16(s) select c;
            product pro = dat.First();
            pro.ProductID = Convert.ToInt16(txtprodid.Text);
            obj.products.DeleteOnSubmit(pro);
            obj.SubmitChanges();
            GridView1.DataBind();
            Response.Write("deleted successfully");
        }

        protected void BTNSEARCH_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext obj = new DataClasses1DataContext(@"Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            string sc = @" select * from product where ProductID =" + txtprodid.Text;
            DataSet ds = new DataSet();
            string s = txtprodid.Text.ToString();
            SqlDataAdapter da = new SqlDataAdapter(sc, cnstr);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            var dat = from c in obj.products where c.ProductID == Convert.ToInt16(s) select c;
            GridView1.DataSource = dat;
            GridView1.DataBind();
            Response.Write(" successfully searched");
            
        }
    }
}