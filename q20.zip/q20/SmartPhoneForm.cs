﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace q20
{
    public partial class SmartPhoneForm : q20.MobileForm
    {
        string sqlcon = @"Data Source=.;Initial Catalog=assignment;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;
        public SmartPhoneForm()
        {
            InitializeComponent();
        }

        public override void btnUpdate_Click(object sender, EventArgs e)
        {
            sqlcmd = "update SmartPhoneDetails set ProductId=" + txtID.Text + ",ProductName='" + txtName.Text + "', UnitPrice=" + txtunitPrice.Text + ", Quantity=" + txtQuantity.Text + ",CameraModel=" + txtCameramodel.Text + ",MobileModel=" + txtMobileModel.Text + ",BatteryDetails=" + txtBatteryDetails.Text + ",AndroidVersion=" + txtAndroidVersion.Text + ",MemoryDetails=" + txtMemoryDetails.Text + " where ProductId=" + txtID.Text + "";

            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        public override void btnDelete_Click(object sender, EventArgs e)
        {
            sqlcmd = "delete from  SmartPhoneDetails where ProductId=" + txtID.Text + "";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        //private void btnInsert_Click_2(object sender, EventArgs e)
        //{

        //    sqlcmd = "insert into SmartPhoneDetails values (" + txtID.Text + ",'" + txtName.Text + "'," + txtunitPrice.Text + "," + txtQuantity.Text + ",'" + txtCameramodel.Text + "','" + txtMobileModel.Text + "','" + txtBatteryDetails.Text + "',"+txtAndroidVersion.Text+",'"+txtMemoryDetails.Text+"')";
        //    ds = new DataSet();
        //    da = new SqlDataAdapter(sqlcmd, sqlcon);
        //    da.Fill(ds);
        //}

       

        public override void  btnrefresh_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            sqlcmd = "select * from SmartPhoneDetails";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        private void SmartPhoneForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            sqlcmd = "select * from SmartPhoneDetails";
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        public override void btnInsert_Click(object sender, EventArgs e) 
        {

            sqlcmd = "insert into SmartPhoneDetails values (" + txtID.Text + ",'" + txtName.Text + "'," + txtunitPrice.Text + "," + txtQuantity.Text + ",'" + txtCameramodel.Text + "','" + txtMobileModel.Text + "','" + txtBatteryDetails.Text + "'," + txtAndroidVersion.Text + ",'" + txtMemoryDetails.Text + "')";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

       
    }
}
