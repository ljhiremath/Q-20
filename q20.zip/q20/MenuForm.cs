﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace q20
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void genericFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void mobileFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MobileForm mfrm = new MobileForm();
            mfrm.Show();
        }

        private void smartPhoneFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SmartPhoneForm smfrm = new SmartPhoneForm();
            smfrm.Show();
        }

        
    }
}
