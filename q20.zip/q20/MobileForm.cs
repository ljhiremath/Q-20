﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace q20
{
    public partial class MobileForm : q20.Form1
    {
        string sqlcon = @"Data Source=.;Initial Catalog=assignment;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;
        public MobileForm()
        {
            InitializeComponent();
        }

       

       

        private void MobileForm_Load(object sender, EventArgs e)
        {
            
            sqlcmd="select * from MobileDetails";
            da=new SqlDataAdapter(sqlcmd,sqlcon);
            ds=new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        public override void btnUpdate_Click(object sender, EventArgs e)
        {
            sqlcmd = "update MobileDetails set ProductId=" + txtID.Text + ",ProductName='" + txtName.Text + "', UnitPrice=" + txtunitPrice.Text + ", Quantity=" + txtQuantity.Text + ",CameraModel=" + txtCameramodel.Text + ",MobileModel=" + txtMobileModel.Text + ",BatteryDetails=" + txtBatteryDetails.Text + " where ProductId=" + txtID.Text + "";

            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        public override void btnDelete_Click(object sender, EventArgs e)
        {
            sqlcmd = "delete from  MobileDetails where ProductId=" + txtID.Text + "";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        public override void btnInsert_Click(object sender, EventArgs e)
        {
            
            sqlcmd = "insert into MobileDetails values (" + txtID.Text + ",'" + txtName.Text + "'," + txtunitPrice.Text + "," + txtQuantity.Text + ",'"+txtCameramodel.Text+"','"+txtMobileModel.Text+"','"+txtBatteryDetails.Text+"')";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        public override void btnrefresh_Click(object sender, EventArgs e)
        {
            
            sqlcmd = "select * from MobileDetails";
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Visible = true;
        }
        

      
       
    }
}
